package com.almasb.libraryloan;

public enum BookSearchType {
    ID, NAME, AUTHOR, PUBLISHED_YEAR, AVAILABLE
}
